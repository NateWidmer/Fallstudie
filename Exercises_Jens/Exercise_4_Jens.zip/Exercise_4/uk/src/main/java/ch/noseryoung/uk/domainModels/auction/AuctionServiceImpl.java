package ch.noseryoung.uk.domainModels.auction;

import ch.noseryoung.uk.domainModels.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class AuctionServiceImpl implements AuctionService {

    private AuctionRepository auctionRepository;
    private UserService userService;

    @Autowired
    public AuctionServiceImpl(AuctionRepository auctionRepository, UserService userService) {
        this.auctionRepository = auctionRepository;
        this.userService = userService;
    }

    @Override
    public Auction create(Auction auction) {
        return auctionRepository.save(auction);
    }

    @Override
    public List<Auction> findAll() {
        return auctionRepository.findAll();
    }



    @Override
    public Auction findById(int id) {
        return auctionRepository.findById(id).get();
    }

    @Override
    public Auction updateById(int id, Auction auction) {
        if(auctionRepository.existsById(id)) {
            auction.setId(id);
            auctionRepository.save(auction);

            return auction;
        } else {
            throw new NoSuchElementException("No value present");
        }
    }

    @Override
    public List<Auction> findByUserId(int id) {
        List<Auction> auctionListWithBids = new ArrayList<>();
        userService.findById(id).getAuctions().forEach(a -> {
            if(a.getBids().size() >= 1){
                auctionListWithBids.add(a);
            }
        });
        return auctionListWithBids;
    }

    @Override
    public void deleteById(int id) {
        auctionRepository.deleteById(id);
    }
}
