package ch.noseryoung.uk.domainModels.auction;
import ch.noseryoung.uk.domainModels.article.Article;
import ch.noseryoung.uk.domainModels.bid.Bid;
import ch.noseryoung.uk.domainModels.user.User;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "auction")
public class Auction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "id")
    private int id;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private double fixed_price;

    @Column(nullable = false)
    private double starting_price;

    @Column(nullable = false)
    private boolean is_public;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "auction_id")
    private List<Bid> bids;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "article_id", referencedColumnName = "id")
    private Article article;
    // Standard empty constructor
    public Auction() {}

    // Getters and setters
    public int getId() {
        return id;
    }

    public Auction setId(int id) {
        this.id = id;
        return this;
    }

    public Article getArticle() {
        return article;
    }

    public Auction setArticle(Article article) {
        this.article = article;
        return this;
    }

    public List<Bid> getBids() {
        return bids;
    }

    public Auction setBids(List<Bid> bids) {
        this.bids = bids;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public ch.noseryoung.uk.domainModels.auction.Auction setDescription(String description) {
        this.description = description;
        return this;
    }

    public double getFixed_price() {
        return fixed_price;
    }

    public Auction setFixed_price(double fixed_price) {
        this.fixed_price = fixed_price;
        return this;
    }

    public double getStarting_price() {
        return starting_price;
    }

    public Auction setStarting_price(double starting_price) {
        this.starting_price = starting_price;
        return this;
    }

    public boolean getIs_public() {
        return is_public;
    }

    public Auction setIsPublic(boolean is_public) {
        this.is_public = is_public;
        return this;
    }
}
