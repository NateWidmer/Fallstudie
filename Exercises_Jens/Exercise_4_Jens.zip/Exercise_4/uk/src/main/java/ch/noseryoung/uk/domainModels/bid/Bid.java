package ch.noseryoung.uk.domainModels.bid;
import ch.noseryoung.uk.domainModels.user.User;

import javax.persistence.*;

@Entity
@Table(name = "bid")
public class Bid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Column(name = "id")
    private int id;

    @Column(nullable = false)
    private double amount;

    public Bid() {}

    public int getId() {
        return id;
    }

    public ch.noseryoung.uk.domainModels.bid.Bid setId(int id) {
        this.id = id;
        return this;
    }

    public double getAmount() {
        return amount;
    }

    public ch.noseryoung.uk.domainModels.bid.Bid setAmount(double amount) {
        this.amount = amount;
        return this;
    }
}
